#!/bin/bash

# Common settings script.

TURNVERSION=4.6.2
BUILDDIR=~/rpmbuild
ARCH=`uname -p`

WGETOPTIONS="--no-check-certificate"
RPMOPTIONS="-ivh --force"


