package io.openrct2;

import android.app.Application;

public class OpenRCT2App extends Application {
}
