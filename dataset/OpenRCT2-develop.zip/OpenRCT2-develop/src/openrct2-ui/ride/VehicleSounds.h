#pragma once

namespace OpenRCT2::Audio
{
    void UpdateVehicleSounds();
}
