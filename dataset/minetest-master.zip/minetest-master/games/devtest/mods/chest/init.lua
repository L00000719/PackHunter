dofile(core.get_modpath("chest").."/chest.lua")
dofile(core.get_modpath("chest").."/detached.lua")
