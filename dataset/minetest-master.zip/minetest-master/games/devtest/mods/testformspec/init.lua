dofile(core.get_modpath("testformspec").."/dummy_items.lua")
dofile(core.get_modpath("testformspec").."/formspec.lua")
dofile(core.get_modpath("testformspec").."/callbacks.lua")
