var searchData=
[
  ['qos_273',['qos',['../struct_m_q_t_t_client__message.html#a35738099155a0e4f54050da474bab2e7',1,'MQTTClient_message::qos()'],['../struct_m_q_t_t_client__will_options.html#a35738099155a0e4f54050da474bab2e7',1,'MQTTClient_willOptions::qos()']]],
  ['quality_20of_20service_274',['Quality of service',['../qos.html',1,'']]]
];
