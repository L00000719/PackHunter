var searchData=
[
  ['quality_20of_20service_611',['Quality of service',['../qos.html',1,'']]]
];
