//
// version.h
//
// Copyright (c) 2012-2014 clib authors
// MIT licensed
//

#ifndef CLIB_VERSION
#define CLIB_VERSION "2.8.7"
#endif
