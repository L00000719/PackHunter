
//
// substr.h
//
// Copyright (c) 2013 Stephen Mathieson
// MIT licensed
//


#ifndef SUBSTR_H
#define SUBSTR_H 1

char *substr(const char *, int, int);

#endif
