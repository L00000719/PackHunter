
//
// str-replace.h
//
// Copyright (c) 2013 Stephen Mathieson
// MIT licensed
//


#ifndef STR_REPLACE_H
#define STR_REPLACE_H

char *str_replace(const char *str, const char *sub, const char *replace);

#endif
