
//
// str-flatten.h
//
// Copyright (c) 2014 Stephen Mathieson
// MIT licensed
//


#ifndef STR_FLATTEN_H
#define STR_FLATTEN_H 1

char *
str_flatten(const char *[], int, int);

#endif
