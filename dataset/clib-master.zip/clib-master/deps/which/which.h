
//
// which.h
//
// Copyright (c) 2013 TJ Holowaychuk <tj@vision-media.ca>
//

#ifndef WHICH_H
#define WHICH_H

char *
which(const char *name);

char *
which_path(const char *name, const char *path);

#endif /* WHICH_H */
