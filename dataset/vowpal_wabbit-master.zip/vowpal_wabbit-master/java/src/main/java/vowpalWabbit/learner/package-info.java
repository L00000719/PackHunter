/**
 * All VW learners exist in this package.  For the learners to work they all must be in the same package.  This forces construction
 * of VW learners to only occur via VWFactory which is desirable as that will force the correct type.
 *
 */
package vowpalWabbit.learner;
