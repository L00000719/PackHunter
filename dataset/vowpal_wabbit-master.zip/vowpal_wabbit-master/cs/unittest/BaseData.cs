﻿namespace cs_unittest
{
    public class BaseData
    {
        public string Line { get; set; }
    }
}
