namespace Vw.Net.Native
{
  public static class VectorAdapter<TValue>
  {
    
  }
}