﻿using namespace System;
using namespace System::Reflection;
using namespace System::Runtime::CompilerServices;
using namespace System::Runtime::InteropServices;
using namespace System::Security::Permissions;

[assembly:AssemblyTitleAttribute("Vowpal Wabbit")];
[assembly:AssemblyDescriptionAttribute("")];
[assembly:AssemblyConfigurationAttribute("")];
[assembly:AssemblyCompanyAttribute("Microsoft Corp")];
[assembly:AssemblyProductAttribute("Vowpal Wabbit")];
[assembly:AssemblyCopyrightAttribute("Copyright (C) 2014")];
[assembly:AssemblyTrademarkAttribute("Copyright (C) Microsoft Corp 2012-2016, Yahoo! Inc. 2007-2012, and many individual contributors. All rights reserved")];
[assembly:AssemblyCultureAttribute("")];
[assembly:AssemblyVersionAttribute("8.10.0")];
[assembly:AssemblyFileVersion("8.10.0")];
