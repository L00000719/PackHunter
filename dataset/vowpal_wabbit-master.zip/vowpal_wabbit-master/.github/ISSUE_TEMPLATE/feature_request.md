---
name: "Feature request"
about: Request/suggest a new feature in VW
title: ''
labels: "Feature Request"
assignees: ''

---

<!-- Please check if there is an existing issue that matches your request -->

## Short description
<!-- Describe your idea -->


## **How this suggestion will help you/others**


## **Possible solution/implementation details**
<!-- Describe the solution you'd like -->


## **Example/links if any**
<!-- Link to already similar features if possible -->
