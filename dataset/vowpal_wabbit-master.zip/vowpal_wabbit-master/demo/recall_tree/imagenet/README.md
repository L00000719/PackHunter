Recall tree demo for imagenet
-------------------------------

This demo exercises the recall tree reduction for logarithmic time 
multiclass classification on the imagenet dataset.  It takes a 
long time to run, a lot of memory, and a lot of disk space.
