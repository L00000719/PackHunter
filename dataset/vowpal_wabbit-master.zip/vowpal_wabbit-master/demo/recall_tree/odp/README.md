Recall tree demo for odp
-------------------------------

This demo exercises the recall tree reduction for logarithmic time 
multiclass classification on the odp dataset.  It takes a 
long time to run, a lot of memory, and a lot of disk space.
