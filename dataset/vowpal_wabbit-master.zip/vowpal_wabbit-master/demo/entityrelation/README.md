Searn for Entity Relation Recognition
-------------------------------------

This demo shows the performance of Searn on an entity-relation recognition task. For more details on the data set see 
http://cogcomp.cs.illinois.edu/page/resource_view/43

### Instructions ###

- `make er.perf`: 
	downloads the preprocessed entity-relation dataset, trains a joint model for predicting entity and relation types and computes test set statistics.

