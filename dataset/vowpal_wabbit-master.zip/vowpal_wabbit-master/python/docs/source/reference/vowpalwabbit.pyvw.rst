vowpalwabbit.pyvw
=================

This is the implementation module for core package functionality. There are a couple of advanced usage classes available here, but for the most part classes in :py:obj:`vowpalwabbit` should be used directly.

.. automodule:: vowpalwabbit.pyvw
    :members:
    :undoc-members:
    :show-inheritance:
