vowpalwabbit.dftovw
====================

This is an optional module which implements a dataframe converter to VW format.

Deprecated alias
----------------

.. deprecated:: 9.0.0
    The module name ``vowpalwabbit.DFtoVW`` has been renamed to :py:mod:`vowpalwabbit.dftovw`. Please use the new module name instead.

Module contents
---------------

.. automodule:: vowpalwabbit.dftovw
    :members:
    :undoc-members:
    :show-inheritance:
