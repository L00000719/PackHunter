vowpalwabbit.pyvw.pylibvw
=========================

The Python bindings employ native bindings and then inherit from this in Python
to add extra functionality. The classes on this page should not be directly
instantiated. The types in :py:obj:`vowpalwabbit` should be used instead.

.. autoclass:: vowpalwabbit.pyvw.pylibvw.vw
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: vowpalwabbit.pyvw.pylibvw.example
    :members:
    :undoc-members:
    :show-inheritance: