# Examples

```{toctree}
:maxdepth: 1

basics
contextual_bandit
epsilon_decay
mini_vw
poisson_regression
predict
search_covington
search_sequence_ldf
search_sequence
search_speech_tagger
```
