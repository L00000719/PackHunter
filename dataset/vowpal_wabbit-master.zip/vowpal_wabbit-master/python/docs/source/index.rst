Vowpal Wabbit
=============

Vowpal Wabbit is a fast machine learning library for online learning.

.. toctree::
   :maxdepth: 2

   tutorials/index
   examples/index
   reference/index
   command_line_args
