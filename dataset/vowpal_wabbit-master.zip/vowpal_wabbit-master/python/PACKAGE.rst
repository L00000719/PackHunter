Python Packaging
================

* Binary wheels are produced in CI according to the `support table <https://github.com/VowpalWabbit/vowpal_wabbit/wiki/Python#support>`_ and uploaded to PyPI for a release.
* There is also a conda package found `here <https://github.com/conda-forge/vowpalwabbit-feedstock>`_
* Instructions on how to release a version of the package can be found `here <https://github.com/VowpalWabbit/vowpal_wabbit/wiki/Python#release-process>`_
