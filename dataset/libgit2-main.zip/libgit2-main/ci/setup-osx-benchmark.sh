#!/bin/sh

set -ex

brew update
brew install hyperfine
