The PostgreSQL code of conduct can be found at
<https://www.postgresql.org/about/policies/coc/>.
