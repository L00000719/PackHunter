#include <iostream>
#include "../Renderer.h"
#include "../FFT.h"
#include "../SetupDialog.h"

namespace SetupDialog
{

bool Open( SetupDialog::SETTINGS * settings )
{
  std::cerr << __FUNCTION__ << " STUB" << std::endl;
  return true;
}

}