#ifndef OSRM_STORAGE_TAR_FWD_HPP_
#define OSRM_STORAGE_TAR_FWD_HPP_

namespace osrm::storage::tar
{

class FileReader;
class FileWriter;

} // namespace osrm::storage::tar

#endif
