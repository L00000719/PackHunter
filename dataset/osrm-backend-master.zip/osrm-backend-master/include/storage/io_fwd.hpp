#ifndef OSRM_STORAGE_IO_FWD_HPP_
#define OSRM_STORAGE_IO_FWD_HPP_

namespace osrm::storage::io
{

class FileReader;
class FileWriter;

} // namespace osrm::storage::io

#endif
